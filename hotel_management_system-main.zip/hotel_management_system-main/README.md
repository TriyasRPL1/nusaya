# hotel_management_system
UJI KOMPENTENSI KEAHLIAN (UKK) REKAYASA PERANGKAT LUNAK SMKN 1 KUWUS 
HOTEL MANAGEMENT SYSTEM USING HTML5 PHP JAVASCRIPT BOOTSTRAP5
Sistem Informasi Pemesanan Hotel Anaya Labuan Bajo - Manggarai Barat NTT - Indonesia

Langkah - Langkah
1. Buat Database pada XAMPP - Localhost
2. Import Database pada Database yang dibuat di PHPMYADMIN
3. Copy dan paste folder hotel pada Folder C://xampp/htdocs
4. Jalankan pada Web browser (chrome, firefox, dll)
5. Link Pelanggan: localhost/hotel/
6. Link Resepsionis: localhost/hotel/resepsionis/
7. Link Admin: localhost/hotel/admin/
8. Selamat mencoba! 

**TAMPILAN MOCKUP**

**HALAMAN HOME**

![HALAMAN HOME](https://user-images.githubusercontent.com/88584119/160518760-b4ac1820-3d33-4af2-ac90-eeccb10fa995.jpg)

**HALAMAN FASILITAS KAMAR**

![HALAMAN FK](https://user-images.githubusercontent.com/88584119/160518806-1c380a98-a46a-4388-b596-d1ae875c6305.jpg)

**HALAMAN FASILITAS UMUM**

![FU](https://user-images.githubusercontent.com/88584119/160518850-b4e91032-e856-4c9d-bf22-42c73b73b010.jpg)

**HALAMAN RESEPSIONIS**

![RESEPSIONIS](https://user-images.githubusercontent.com/88584119/160518885-a98cbcce-08e8-4c58-8339-0e136cdb7fc8.jpg)

**HALAMAN ADMIN-KAMAR**

![ADMIN-KAMAR](https://user-images.githubusercontent.com/88584119/160518931-4ccbb4eb-780d-4f32-8693-c7e666e758bd.jpg)

**HALAMAN ADMIN-FASILITAS KAMAR**

![ADMIN-FK](https://user-images.githubusercontent.com/88584119/160519004-d08b6094-8ca3-4370-9eb4-861aca3db9e9.jpg)

HALAMAN ADMIN-FASILITAS UMUM

![ADMIN-FU](https://user-images.githubusercontent.com/88584119/160519045-37c1d3dd-aa91-44ba-8bde-746eda225c4f.jpg)



Link Demo : https://ukk-rpl-2022.smkn1kuwus.sch.id/

Link Tutorial Youtube:
https://www.youtube.com/channel/UCmIL-UoO0RNQBHPrsbBTJmw/featured




