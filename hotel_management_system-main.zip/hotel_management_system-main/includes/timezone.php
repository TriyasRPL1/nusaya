<?php
	$timezone = 'Asia/Makassar';
	date_default_timezone_set($timezone);
?>